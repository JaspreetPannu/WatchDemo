//
//  AppDelegate.swift
//  WatchDemo
//
//  Created by Jaspreet Pannu on 2020-08-17.
//  Copyright © 2020 Jaspreet Pannu. All rights reserved.
//

import WatchKit
import Foundation
import WatchConnectivity


class InterfaceController: WKInterfaceController,WCSessionDelegate
{
    
    @IBOutlet weak var sendbutton: WKInterfaceButton!
    var userResponse = ""

    
    @IBOutlet weak var replylabel: WKInterfaceLabel!
    
    var labelSaysHello:Bool = true

    @IBOutlet weak var messageLabel: WKInterfaceLabel!
    
    override func awake(withContext context: Any?) {
        super.awake(withContext: context)
        
        // Configure interface objects here.
    }
    
    
    
    func session(_ session: WCSession, activationDidCompleteWith activationState: WCSessionActivationState, error: Error?) {
           

       }
    func session(_ session: WCSession, didReceiveMessage message: [String : Any]) {
        // Play a "click" sound when you get the message
        WKInterfaceDevice().play(.click)
        
        DispatchQueue.main.async{
                           if let value = message["Iphone"] as? String
                           {
                           print(message)
                            self.messageLabel.setHidden(false)
                            self.messageLabel.setText(value)
                           }
                                      // update the message with a label
    }
    }
    
    override func willActivate() {
        // This method is called when watch view controller is about to be visible to user
        super.willActivate()
        print("Welcome")
        if WCSession.isSupported() {
        let session = WCSession.default
        session.delegate = self
        session.activate()
            replylabel.setHidden(true)
            messageLabel.setHidden(true)
            if userResponse.isEmpty {
                sendbutton.setHidden(true)
            }
    
        }
    }
    
    @IBAction func buttonClicked()
    {
       // 1. Wtrhen person clicks on button, show them the input UI
                    let suggestedResponses = ["In class", "Doing Assignment", "At movies", "Sleeping"]
             presentTextInputController(withSuggestions: suggestedResponses, allowedInputMode: .allowEmoji) { (results) in
                       
                       
                        if (results != nil && results!.count > 0)  {
                            // 2. write your code to process the person's response
                            self.userResponse = (results?.first as? String)!
                            
                            self.replylabel.setText(self.userResponse)
                            
                            self.sendbutton.setHidden(false)
                            self.replylabel.setHidden(false)
                        }
                    }
        
    }
    
    
    override func didDeactivate() {
        // This method is called when watch view controller is no longer visible
        super.didDeactivate()
    }

    @IBAction func send() {
        
        
        if (WCSession.default.isReachable) {
                // construct the message you want to send
                // the message is in dictionary
            
            let message = ["Watch": userResponse]
               // send the message to the watch
            WCSession.default.sendMessage(message as [String : Any], replyHandler: nil)
    
        }
}
    
}
