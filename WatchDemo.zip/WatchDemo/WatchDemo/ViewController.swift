//
//  AppDelegate.swift
//  WatchDemo
//
//  Created by Jaspreet Pannu on 2020-08-17.
//  Copyright © 2020 Jaspreet Pannu. All rights reserved.
//

import UIKit
import WatchConnectivity

class ViewController: UIViewController,WCSessionDelegate {
    
    @IBOutlet weak var messagelabel: UILabel!
    @IBOutlet weak var ask: UITextField!
    
    func session(_ session: WCSession, activationDidCompleteWith activationState: WCSessionActivationState, error: Error?) {
       print("Run")
    }
    
    func sessionDidBecomeInactive(_ session: WCSession) {
        
    }
    
    func sessionDidDeactivate(_ session: WCSession) {
        print("Finish")
    }
    

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        
        
        print("checking to see if wc session is supported")
              
              // Check if your IOS version can talk to the phone
               // Does your iPhone support "talking to a watch"?
              // If yes, then create the session
              // If no, then output error message
              if (WCSession.isSupported()) {
                  print("PHONE: Phone supports WatchConnectivity!")
                  let session = WCSession.default
                  session.delegate = self
                  session.activate()
              }
              else {
                  print("PHONE: Phone does not support WatchConnectivity")
              }
        messagelabel.isHidden = true
      
    
    }

    @IBAction func buttonClicked(_ sender: Any) {
        
        if (WCSession.default.isReachable) {
         // construct the message you want to send
         // the message is in dictionary
            let message = ["Iphone": ask.text]
        // send the message to the watch
         WCSession.default.sendMessage(message, replyHandler: nil)

        
    }
//       func session(_ session: WCSession, didReceiveMessage message: [String : Any], replyHandler: @escaping ([String : Any]) -> Void) {
//
//
//               // output a debug message to the terminal
//               print("IPHONE: Got a message!")
//               print(message)
//               // update the message with a label
//               messagelabel.text = ("\(message)")
//           }
        
     
}
    func session(_ session: WCSession, didReceiveMessage message: [String : Any]) {
           // Play a "click" sound when you get the message
           
           
           DispatchQueue.main.async{
                              if let value = message["Watch"] as? String
                              {
                              print(message)
                                self.messagelabel.isHidden = false
                               self.messagelabel.text = value
                              }
                                         // update the message with a label
       }
       }
}
